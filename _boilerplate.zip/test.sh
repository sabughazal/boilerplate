python test.py \
    --dataset-root "" \
    --run-path "" \
    --config "" \
    --checkpoint "" \
    --gpu "cuda" \