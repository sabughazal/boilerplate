python main.py \
    --config "" \
    --dataset-root "" \
    --run-name "run001" \
    --output-folder "runs" \
    --patience 25 \
    --gpu "cuda" \
    --resume \
    --checkpoint "" \
    