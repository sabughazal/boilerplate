import torch.nn as nn

class CNN(nn.Module):
    def __init__(self, input_size, num_classes):
        pass

    def forward(self, x):
        pass